# Inlämning 2
# Av Erik Isaksson och Miranda Nilhag
# Orginalhemsida: https://suzannacollinsbooks.com

Hemsidan vi valde såg inte modern ut men var responsiv. 
Problemet med hemsidan är att den inte är mobilanpassad, i desktop och tablet så ser den snarlik ut men använder man en mobilskärm så ser inte innehållet attraktivt ut. 

Hemsidan i sig är ganska tråkig och inte speciellt inbjudande.
Då hon inte använt sig av en header så valde vi att skapa en logga med hennes signatur, ikoner med länkar till social medier och en "burger" sidebar med animation.

Avgränsningar:
• Vi valde att inte använda oss av Bootstrap eller Tailwind
-Vi hade redan kommit långt in i projektet och skrivit egen CSS men vi gjorde några försök men kom fram till att vi lär oss mer av att inte använda det i detta projektet.


Då det inte fanns någonstans på sidan där man kunde ta kontakt med författaren så valde vi att göra det som vår andra sida. 
Därför finns det endast skrämdumpar av startsidan.


